<?php
$id_pasien = 1;
$nama_pasien = 'Iin Sholihin';
$sebagai = 'pasien';

$profil = "<img src='img/pasien/$id_pasien.jpg' alt='pasien-$id_pasien' class='foto_profil'>";
