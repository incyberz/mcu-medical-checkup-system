<section style="min-height: 100vh;">
  <div class="sub_form section_name tengah">COVER</div>
  <h1 class="tengah">MEDICAL RECORD <br>MMC - CLINIC</h1>
  <H2 class="tengah" style="margin: 50px 0">KLINIK MUTIARA 1</H2>

  <div style="max-width: 500px; margin:auto">

    <div class="tengah">
      <?= $profil ?>
    </div>
    <table class="table">
      <tr>
        <td>NAMA</td>
        <td>:</td>
        <td>IIN SHOLIHIN</td>
      </tr>
      <tr>
        <td>TTL</td>
        <td>:</td>
        <td>SUMEDANG, 10 JUNI 1989</td>
      </tr>
      <tr>
        <td>NIK</td>
        <td>:</td>
        <td>3211111006890004</td>
      </tr>
      <tr>
        <td>STATUS</td>
        <td>:</td>
        <td>MENIKAH</td>
      </tr>
      <tr>
        <td>ALAMAT</td>
        <td>:</td>
        <td>DESA BABAKAN - CIWARINGIN - CIREBON</td>
      </tr>
    </table>

    <div class="f14 tengah" style="margin-top: 50px;">MMC - Clinic : Perum Metland Jln. Kalimaya VI Blok L2 No. 1 Tambun - Bekasi Telp. (021) 2948 7893 Email : mutiara_mmc@yahoo.co.id</div>
  </div>


</section>