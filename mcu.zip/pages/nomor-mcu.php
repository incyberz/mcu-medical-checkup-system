<h2>NOMOR MCU</h2>
<div class="wadah tengah f50 darkblue bold consolas">
  1056
</div>

<table class="table">
  <tr>
    <td>PAKET</td>
    <td>:</td>
    <td>A</td>
  </tr>
  <tr>
    <td>JADWAL PEMERIKSAAN</td>
    <td>:</td>
    <td>1 APRIL 2024</td>
  </tr>
  <tr>
    <td>TIPE MCU</td>
    <td>:</td>
    <td>ONSITE (DI PERUSAHAAN)</td>
  </tr>
  <tr>
    <td colspan="100%">
      <div class="tengah f12 abu">
        ESTIMASI PEMERIKSAAN DALAM
      </div>
      <div class='consolas f30 tengah'>
        3d:5h:34m:12s
      </div>
    </td>
  </tr>
</table>