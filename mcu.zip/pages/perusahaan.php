<h2>PERUSAHAAN</h2>
<table class="table">
  <tr>
    <td>NAMA PERUSAHAAN</td>
    <td>:</td>
    <td>PT. ABC</td>
  </tr>
  <tr>
    <td>ANDA SEBAGAI</td>
    <td>:</td>
    <td>
      <div>
        <label>
          <input type="radio" name="sebagai_karyawan"> KARYAWAN (EMPLOYEE)
        </label>
      </div>
      <div>
        <label>
          <input type="radio" name="sebagai_karyawan"> CALON KARYAWAN (PRE-EMPLOYEE)
        </label>
      </div>
    </td>
  </tr>
  <tr>
    <td>TANGGAL DITERIMA</td>
    <td>:</td>
    <td>11 JULI 2020</td>
  </tr>
  <tr>
    <td>JENIS PEKERJAAN</td>
    <td>:</td>
    <td>
      <select class="form-control">
        <option value="1">Operator</option>
        <option value="2">Staf/Managerial</option>
      </select>
    </td>
  </tr>
  <tr>
    <td>DEPARTEMEN</td>
    <td>:</td>
    <td>
      <input type="text" class="form-control">
    </td>
  </tr>
</table>