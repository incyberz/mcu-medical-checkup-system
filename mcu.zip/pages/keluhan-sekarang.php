<h2>KELUHAN SEKARANG</h2>
<textarea class="form-control mt4 mb4" name="keluhan_sekarang" id="keluhan_sekarang" rows="10"></textarea>