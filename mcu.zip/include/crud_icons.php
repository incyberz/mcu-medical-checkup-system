<?php
$img_edit = '<img class="zoom pointer" src="assets/img/icons/edit.png" alt="edit" height=20px>';
$img_delete = '<img class="zoom pointer" src="assets/img/icons/delete.png" alt="delete" height=20px>';
$img_delete_disabled = '<img class="zoom pointer" src="assets/img/icons/delete_disabled.png" alt="delete_disabled" height=20px>';
$img_add = '<img class="zoom pointer" src="assets/img/icons/add.png" alt="add" height=20px>';
$img_save = '<img class="zoom pointer" src="assets/img/icons/save.png" alt="save" height=20px>';
$img_close = '<img class="zoom pointer" src="assets/img/icons/close.png" alt="close" height=20px>';
$img_cancel = '<img class="zoom pointer" src="assets/img/icons/cancel.png" alt="cancel" height=20px>';
$img_detail = '<img class="zoom pointer" src="assets/img/icons/detail.png" alt="detail" height=20px>';
$img_unique = '<img class="zoom pointer" src="assets/img/icons/unique.png" alt="unique" height=20px>';
$img_manage = '<img class="zoom pointer" src="assets/img/icons/manage.png" alt="manage" height=20px>';
$img_login_as = '<img class="zoom pointer" src="assets/img/icons/login_as.png" alt="login_as" height=20px>';
$img_help = '<img class="zoom pointer" src="assets/img/icons/help.png" alt="help" height=20px>';
$img_check = '<img class="zoom pointer" src="assets/img/icons/check.png" alt="check" height=20px>';
$img_warning = '<img class="zoom pointer" src="assets/img/icons/warning.png" alt="warning" height=20px>';
$img_next = '<img class="zoom pointer" src="assets/img/icons/next.png" alt="next" height=20px>';
$img_prev = '<img class="zoom pointer" src="assets/img/icons/prev.png" alt="prev" height=20px>';
$img_locked = '<img class="zoom pointer" src="assets/img/icons/locked.png" alt="locked" height=20px>';
$img_sum = '<img class="zoom pointer" src="assets/img/icons/sum.png" alt="sum" height=20px>';
$img_sum_disabled = '<img class="zoom pointer" src="assets/img/icons/sum_disabled.png" alt="sum_disabled" height=20px>';



$bintang = '<span class="tebal red pointer" onclick="alert(\'Field ini wajib diisi.\')">*</span>';
$unique = '<span class="tebal blue pointer" onclick="alert(\'Field ini isinya harus unique.\')">*</span>';


$fs_icon = ' <b class="f14 ml1 mr1 biru p1 pr2 br5" style="display:inline-block;background:green;color:white">FS</b>';
$img_fs = $fs_icon;